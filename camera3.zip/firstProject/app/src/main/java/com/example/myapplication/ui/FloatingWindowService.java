package com.example.myapplication.ui;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Bundle;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.Surface;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageButton;
import android.widget.RelativeLayout;
import androidx.annotation.Nullable;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.Preview;
import androidx.camera.core.SurfaceRequest;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.ProcessLifecycleOwner;

import com.example.myapplication.R;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class FloatingWindowService extends Service {

    private WindowManager windowManager;
    private View floatingView;
    private WindowManager.LayoutParams params;

    private float initialX, initialY;
    private float initialTouchX, initialTouchY;
    private boolean isResizing = false;

    @Override
    public void onCreate() {
        super.onCreate();

        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        // Inflate the floating window layout
        floatingView = LayoutInflater.from(this).inflate(R.layout.floating_window, null);

        // Define layout parameters for the floating window
        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT
        );

        params.gravity = Gravity.TOP | Gravity.START;

        // Add the floating window to the window manager
        windowManager.addView(floatingView, params);

        // Initialize CameraX
        initializeCameraX();

        // Setup touch listeners for moving and resizing
        setupTouchListeners();
    }

    private void setupTouchListeners() {
        final View resizeButton = floatingView.findViewById(R.id.resize_button);
        final View closeButton = floatingView.findViewById(R.id.close_button);

        floatingView.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                initialX = params.x;
                initialY = params.y;
                initialTouchX = event.getRawX();
                initialTouchY = event.getRawY();
            } else if (event.getAction() == MotionEvent.ACTION_MOVE) {
                if (!isResizing) {
                    params.x = (int) (initialX + (event.getRawX() - initialTouchX));
                    params.y = (int) (initialY + (event.getRawY() - initialTouchY));
                    windowManager.updateViewLayout(floatingView, params);
                } else {
                    int width = (int) (event.getRawX() - params.x);
                    int height = (int) (event.getRawY() - params.y);
                    params.width = Math.max(width, 100);  // Minimum width
                    params.height = Math.max(height, 100); // Minimum height
                    windowManager.updateViewLayout(floatingView, params);
                }
            }
            return true;
        });

        resizeButton.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                isResizing = true;
            } else if (event.getAction() == MotionEvent.ACTION_UP) {
                isResizing = false;
            }
            return true;
        });

        closeButton.setOnClickListener(v -> stopSelf());
    }

    private void initializeCameraX() {
        final SurfaceView surfaceView = floatingView.findViewById(R.id.camera_surface);

        if (surfaceView == null) {
            throw new NullPointerException("SurfaceView not found in floating window layout");
        }

        Executor cameraExecutor = Executors.newSingleThreadExecutor();

        ProcessCameraProvider.getInstance(this).addListener(() -> {
            try {
                ProcessCameraProvider cameraProvider = ProcessCameraProvider.getInstance(FloatingWindowService.this).get();
                Preview preview = new Preview.Builder().build();

                preview.setSurfaceProvider(surfaceRequest -> {
                    SurfaceHolder surfaceHolder = surfaceView.getHolder();
                    Surface surface = surfaceHolder.getSurface();

                    // Check if the Surface is available
                    if (surface != null) {
                        // Provide the Surface with a result callback
                        surfaceRequest.provideSurface(surface, cameraExecutor, result -> {
                            // Handle SurfaceRequest result here if needed
                        });
                    } else {
                        // Handle the situation where Surface is not available
                        surfaceHolder.addCallback(new SurfaceHolder.Callback() {
                            @Override
                            public void surfaceCreated(SurfaceHolder holder) {
                                Surface surface = holder.getSurface();
                                surfaceRequest.provideSurface(surface, cameraExecutor, result -> {
                                    // Handle SurfaceRequest result here if needed
                                });
                            }

                            @Override
                            public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {
                                // Optionally handle surface changes
                            }

                            @Override
                            public void surfaceDestroyed(SurfaceHolder holder) {
                                // Optionally handle surface destruction
                            }
                        });
                    }
                });

                CameraSelector cameraSelector = new CameraSelector.Builder()
                        .requireLensFacing(CameraSelector.LENS_FACING_BACK)
                        .build();

                cameraProvider.bindToLifecycle(ProcessLifecycleOwner.get(), cameraSelector, preview);

            } catch (ExecutionException | InterruptedException e) {
                e.printStackTrace();
            }
        }, ContextCompat.getMainExecutor(this));
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (floatingView != null) {
            windowManager.removeView(floatingView);
        }
    }
}
